const fs = require("fs");
function analyzeFile(filepath) {
  const lines = fs.readFileSync(filepath, "utf8").split("\n");
  const sectionIds = {};
  const commentSections = {};
  lines.forEach(function(line, i) {
    var ln = i + 1;
    var idMatch = line.match(/id="([^"]+)"/);
    if (idMatch && line.includes("<section")) {
      var id = idMatch[1];
      if (sectionIds[id] == null) sectionIds[id] = [];
      sectionIds[id].push(ln);
    }
    var cMatch = line.match(/<\!--\s*([A-Z][A-Z '#-]+[A-Z])\s*(-->|$)/);
    if (cMatch) {
      var name = cMatch[1].trim();
      if (name.length > 3) {
        if (commentSections[name] == null) commentSections[name] = [];
        commentSections[name].push(ln);
      }
    }
  });
  console.log("\n=== " + filepath.split("/").pop() + " ===");
  console.log("\n-- DUPLICATE IDs --");
  var dupes = false;
  Object.keys(sectionIds).forEach(function(id) {
    if (sectionIds[id].length > 1) { console.log("  id=" + id + " at: " + sectionIds[id].join(", ")); dupes = true; }
  });
  if (\!dupes) console.log("  None");
  console.log("\n-- DUPLICATE COMMENTS --");
  dupes = false;
  Object.keys(commentSections).forEach(function(name) {
    if (commentSections[name].length > 1) { console.log("  " + name + " at: " + commentSections[name].join(", ")); dupes = true; }
  });
  if (\!dupes) console.log("  None");
  console.log("\n-- ALL IDs --");
  Object.keys(sectionIds).forEach(function(id) { console.log("  id=" + id + " => " + sectionIds[id].join(", ")); });
}
analyzeFile("/opt/polsia/workspaces/company-55743/agent-30/exec-2468373/relio-2/public/propops-trade.html");
analyzeFile("/opt/polsia/workspaces/company-55743/agent-30/exec-2468373/relio-2/public/index.html");
