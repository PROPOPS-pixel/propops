const fs = require('fs');
let content = fs.readFileSync('views/dashboard.html', 'utf8');
const origLen = content.length;
let changes = 0;

// 1. Add id="smsToggleRow" to the SMS toggle row
const OLD_SMS_ROW = '<div class="notif-toggle-row">\n                    <div>\n                        <div class="notif-toggle-label">SMS alerts</div>';
const NEW_SMS_ROW = '<div class="notif-toggle-row" id="smsToggleRow">\n                    <div>\n                        <div class="notif-toggle-label">SMS alerts</div>';
if (content.includes(OLD_SMS_ROW)) {
  content = content.replace(OLD_SMS_ROW, NEW_SMS_ROW);
  console.log('OK: Added id to SMS row');
  changes++;
} else {
  console.log('FAIL: SMS row not found');
}

// 2. Update loadSettings to handle sms_available flag
// Find the exact end of the existing assignments
const MARKER = "document.getElementById('toggleDigest').checked     = !!s.notify_daily_digest;";
const markerIdx = content.indexOf(MARKER);
if (markerIdx >= 0) {
  const insertAfter = markerIdx + MARKER.length;
  const SMS_LOGIC = `

                // Show/hide SMS toggle based on server-reported availability
                const smsRow = document.getElementById('smsToggleRow');
                if (smsRow) {
                    smsRow.style.display = (data.sms_available === false) ? 'none' : '';
                }`;
  content = content.slice(0, insertAfter) + SMS_LOGIC + content.slice(insertAfter);
  console.log('OK: Added sms_available handling to loadSettings');
  changes++;
} else {
  console.log('FAIL: toggleDigest marker not found');
}

fs.writeFileSync('views/dashboard.html', content);
console.log('Done. Changes:', changes, 'New size:', content.length, 'Delta:', content.length - origLen);
