const fs = require('fs');
let content = fs.readFileSync('server.js', 'utf8');
const origLen = content.length;

const OLD_ROUTE = `// Dashboard page — requires valid session
// dashboard.html lives in views/ (not public/) so express.static cannot serve it
// without auth. Both /dashboard and /dashboard.html are protected.
app.get(['/dashboard', '/dashboard.html'], (req, res) => {
  const auth = require('./services/auth');
  const cookieToken = req.cookies && (req.cookies['propops_session'] || req.cookies['relio_session']);
  if (!cookieToken || !auth.verifySessionToken(cookieToken)) {
    return res.redirect('/login');
  }
  res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});`;

const NEW_ROUTE = `// Dashboard page — requires valid session + active subscription
// dashboard.html lives in views/ (not public/) so express.static cannot serve it
// without auth. Both /dashboard and /dashboard.html are protected.
app.get(['/dashboard', '/dashboard.html'], async (req, res) => {
  const auth = require('./services/auth');
  const cookieToken = req.cookies && (req.cookies['propops_session'] || req.cookies['relio_session']);
  if (!cookieToken || !auth.verifySessionToken(cookieToken)) {
    return res.redirect('/login');
  }

  // Subscription enforcement: block expired/cancelled accounts from accessing the dashboard.
  // Active = subscription_status 'active', OR trial not yet expired, OR cancelled with future grace period.
  try {
    const payload = auth.verifySessionToken(cookieToken);
    const user = await auth.getUserById(payload.sub);
    if (user) {
      const now = new Date();
      const status = user.subscription_status;
      const trialEnd = user.trial_end ? new Date(user.trial_end) : null;
      const expiresAt = user.subscription_expires_at ? new Date(user.subscription_expires_at) : null;
      const graceEnd = user.grace_period_ends_at ? new Date(user.grace_period_ends_at) : null;

      const hasAccess =
        status === 'active' ||
        (status === 'trial' && trialEnd && trialEnd > now) ||
        (status === 'cancelled' && expiresAt && expiresAt > now) ||
        (status === 'cancelled' && graceEnd && graceEnd > now);

      if (!hasAccess) {
        console.log(\`[Auth] Subscription expired — blocking dashboard for user \${user.id} (\${user.email})\`);
        return res.redirect('/#pricing');
      }
    }
  } catch (err) {
    // On DB error, let the user through — don't accidentally lock out paying customers
    console.error('[Auth] Subscription check error:', err.message);
  }

  res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});`;

if (content.includes(OLD_ROUTE)) {
  content = content.replace(OLD_ROUTE, NEW_ROUTE);
  fs.writeFileSync('server.js', content);
  console.log('OK: Dashboard route updated with subscription enforcement');
  console.log('New size:', content.length, 'Added:', content.length - origLen, 'bytes');
} else {
  console.log('FAIL: Old dashboard route text not found!');
  // Try to find where it is
  const idx = content.indexOf("app.get(['/dashboard', '/dashboard.html']");
  console.log('Route found at:', idx);
  if (idx >= 0) {
    console.log('Context:', JSON.stringify(content.slice(idx - 100, idx + 300)));
  }
}
