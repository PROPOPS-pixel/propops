const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', '..', 'public', 'index.html'), 'utf8');
console.log('Plumber found:', /\bPlumber\b/i.test(html));
console.log('Real Estate found:', /\bReal Estate\b/i.test(html));
console.log('Electrician found:', /\bElectrician\b/i.test(html));

const tradePillRegex = /<(?:span|div|li)[^>]*class="[^"]*(?:trade|pill|tag)[^"]*"[^>]*>([^<]+)<\/(?:span|div|li)>/gi;
const pills = [];
let m;
while ((m = tradePillRegex.exec(html)) !== null) {
  const t = m[1].trim();
  if (t && t.length < 40 && !t.includes('+') && !t.includes('${')) pills.push(t);
}
console.log('Valid pill count:', pills.length, pills.slice(0,5));

// Show what keyword scan finds
const knownTrades = ['Plumber', 'Electrician', 'Lawn Care', 'Painter', 'Builder', 'Real Estate', 'Handyman', 'Landscaper'];
const found = knownTrades.filter(t => new RegExp('\\b' + t + '\\b', 'i').test(html));
console.log('Keyword scan found:', found);
