const fs = require('fs');
let content = fs.readFileSync('views/dashboard.html', 'utf8');
const origLen = content.length;

// 1. Fix placeholder text
content = content.replace(
  'placeholder="e.g. sarah.propops@gmail.com" autocomplete="off"',
  'placeholder="e.g. your@email.com" autocomplete="off"'
);

// 2. Remove oninput handler from agent name input
content = content.replace(' oninput="updateGmailSuggestion()"', '');

// 3. Remove the entire gmailSuggestionBox div
const boxStart = content.indexOf('<div id="gmailSuggestionBox"');
if (boxStart >= 0) {
  let depth = 0;
  let i = boxStart;
  while (i < content.length) {
    if (content.slice(i, i+4) === '<div') depth++;
    if (content.slice(i, i+6) === '</div>') {
      depth--;
      if (depth === 0) {
        const boxText = content.slice(boxStart, i + 6);
        content = content.slice(0, boxStart) + content.slice(i + 6);
        console.log('Removed gmailSuggestionBox, length:', boxText.length);
        break;
      }
    }
    i++;
  }
} else {
  console.log('gmailSuggestionBox not found!');
}

// 4. Remove updateGmailSuggestion() call in loadSettings and the comment above it
const commentAndCall = '// Update Gmail suggestion after loading name\n                updateGmailSuggestion();';
if (content.includes(commentAndCall)) {
  content = content.replace(commentAndCall, '');
  console.log('Removed updateGmailSuggestion() call from loadSettings');
} else {
  console.log('WARN: updateGmailSuggestion() call not found in expected context, trying alternate');
  if (content.includes('updateGmailSuggestion();')) {
    content = content.replace('updateGmailSuggestion();', '');
    console.log('Removed updateGmailSuggestion() call (alternate)');
  }
}

// 5. Remove the updateGmailSuggestion function and its JSDoc comment
const updateFuncIdx = content.indexOf('function updateGmailSuggestion()');
if (updateFuncIdx >= 0) {
  // Find the start of the comment block before it
  const commentSearch = '\n        /**';
  let commentStart = updateFuncIdx;
  // Search backward for the comment
  for (let j = updateFuncIdx - 1; j >= 0; j--) {
    if (content.slice(j, j + commentSearch.length) === commentSearch) {
      commentStart = j;
      break;
    }
    if (j < updateFuncIdx - 300) break; // Don't go too far back
  }

  let braceCount = 0;
  let started = false;
  let i = updateFuncIdx;
  while (i < content.length) {
    if (content[i] === '{') { braceCount++; started = true; }
    if (content[i] === '}') { braceCount--; }
    if (started && braceCount === 0) {
      const toRemove = content.slice(commentStart, i + 1);
      content = content.slice(0, commentStart) + content.slice(i + 1);
      console.log('Removed updateGmailSuggestion function, length:', toRemove.length);
      break;
    }
    i++;
  }
} else {
  console.log('updateGmailSuggestion function not found!');
}

// 6. Remove the copySuggestedGmail function and its JSDoc comment
const copyFuncIdx = content.indexOf('function copySuggestedGmail()');
if (copyFuncIdx >= 0) {
  const commentSearch = '\n        /**';
  let commentStart = copyFuncIdx;
  for (let j = copyFuncIdx - 1; j >= 0; j--) {
    if (content.slice(j, j + commentSearch.length) === commentSearch) {
      commentStart = j;
      break;
    }
    if (j < copyFuncIdx - 300) break;
  }

  let braceCount = 0;
  let started = false;
  let i = copyFuncIdx;
  while (i < content.length) {
    if (content[i] === '{') { braceCount++; started = true; }
    if (content[i] === '}') { braceCount--; }
    if (started && braceCount === 0) {
      const toRemove = content.slice(commentStart, i + 1);
      content = content.slice(0, commentStart) + content.slice(i + 1);
      console.log('Removed copySuggestedGmail function, length:', toRemove.length);
      break;
    }
    i++;
  }
} else {
  console.log('copySuggestedGmail function not found!');
}

fs.writeFileSync('views/dashboard.html', content);
console.log('Done. Original size:', origLen, 'New size:', content.length, 'Removed:', origLen - content.length, 'bytes');

// Verify
const checks = [
  ['gmailSuggestionBox removed', !content.includes('gmailSuggestionBox')],
  ['updateGmailSuggestion removed', !content.includes('updateGmailSuggestion')],
  ['copySuggestedGmail removed', !content.includes('copySuggestedGmail')],
  ['placeholder fixed', content.includes('placeholder="e.g. your@email.com"')],
];
checks.forEach(([name, ok]) => console.log((ok ? 'OK' : 'FAIL') + ': ' + name));
