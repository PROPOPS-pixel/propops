
const crypto = require('crypto');

function verifySvixSignature(rawBody, headers, secret) {
  const msgId = headers['svix-id'];
  const msgTimestamp = headers['svix-timestamp'];
  const msgSignature = headers['svix-signature'];

  if (!msgId || !msgTimestamp || !msgSignature) return false;

  const now = Math.floor(Date.now() / 1000);
  const ts = parseInt(msgTimestamp, 10);
  if (isNaN(ts) || Math.abs(now - ts) > 300) return false;

  const secretBytes = Buffer.from(secret.replace(/^whsec_/, ''), 'base64');
  const bodyStr = Buffer.isBuffer(rawBody) ? rawBody.toString('utf8') : String(rawBody);
  const toSign = `${msgId}.${msgTimestamp}.${bodyStr}`;

  const hmac = crypto.createHmac('sha256', secretBytes);
  const computedSig = hmac.update(toSign).digest('base64');

  const providedSigs = msgSignature.split(' ').map(s => s.replace(/^v1,/, ''));
  return providedSigs.some(sig => {
    try {
      return crypto.timingSafeEqual(Buffer.from(computedSig), Buffer.from(sig));
    } catch { return false; }
  });
}

const REAL_SECRET  = 'whsec_22tOsIgBmEl6eMSG5N3T9gHNi+mcMgzx';
const WRONG_SECRET = 'whsec_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';

const rawBody      = JSON.stringify({ event: 'test.event', data: { id: 42 } });
const msgId        = 'msg_test_' + Date.now();
const msgTimestamp = String(Math.floor(Date.now() / 1000));

const secretBytes = Buffer.from(REAL_SECRET.replace(/^whsec_/, ''), 'base64');
const toSign      = `${msgId}.${msgTimestamp}.${rawBody}`;
const correctSig  = crypto.createHmac('sha256', secretBytes).update(toSign).digest('base64');

console.log('=== Svix Signature Verification Test ===');
console.log('Secret (real)  :', REAL_SECRET);
console.log('Message ID     :', msgId);
console.log('Timestamp      :', msgTimestamp);
console.log('Raw body       :', rawBody);
console.log('String to sign :', toSign);
console.log('Computed sig   :', correctSig);
console.log('');

// TEST 1: valid sig + correct secret
const h1 = { 'svix-id': msgId, 'svix-timestamp': msgTimestamp, 'svix-signature': 'v1,' + correctSig };
const r1 = verifySvixSignature(rawBody, h1, REAL_SECRET);
console.log('TEST 1 — Valid signature + correct secret');
console.log('  Expected : true   Got:', r1, '  Status:', r1 === true ? 'PASS' : 'FAIL');
console.log('');

// TEST 2: valid sig + wrong secret
const r2 = verifySvixSignature(rawBody, h1, WRONG_SECRET);
console.log('TEST 2 — Valid signature + WRONG secret');
console.log('  Expected : false  Got:', r2, '  Status:', r2 === false ? 'PASS' : 'FAIL');
console.log('');

// TEST 3: tampered body
const tamperedBody = JSON.stringify({ event: 'test.event', data: { id: 99 } });
const r3 = verifySvixSignature(tamperedBody, h1, REAL_SECRET);
console.log('TEST 3 — Tampered body + correct secret');
console.log('  Expected : false  Got:', r3, '  Status:', r3 === false ? 'PASS' : 'FAIL');
console.log('');

// TEST 4: multiple sigs in header, one correct
const wrongSig = crypto.createHmac('sha256', Buffer.from(WRONG_SECRET.replace(/^whsec_/, ''), 'base64'))
  .update(toSign).digest('base64');
const h4 = { 'svix-id': msgId, 'svix-timestamp': msgTimestamp,
             'svix-signature': 'v1,' + wrongSig + ' v1,' + correctSig };
const r4 = verifySvixSignature(rawBody, h4, REAL_SECRET);
console.log('TEST 4 — Multiple sigs in header (one wrong, one correct)');
console.log('  Expected : true   Got:', r4, '  Status:', r4 === true ? 'PASS' : 'FAIL');
console.log('');

// TEST 5: expired timestamp
const oldTs = String(Math.floor(Date.now() / 1000) - 400);
const toSignOld = `${msgId}.${oldTs}.${rawBody}`;
const oldSig = crypto.createHmac('sha256', secretBytes).update(toSignOld).digest('base64');
const h5 = { 'svix-id': msgId, 'svix-timestamp': oldTs, 'svix-signature': 'v1,' + oldSig };
const r5 = verifySvixSignature(rawBody, h5, REAL_SECRET);
console.log('TEST 5 — Expired timestamp (400 s old)');
console.log('  Expected : false  Got:', r5, '  Status:', r5 === false ? 'PASS' : 'FAIL');
console.log('');

const all = [r1 === true, r2 === false, r3 === false, r4 === true, r5 === false];
const passed = all.filter(Boolean).length;
console.log('=== Results: ' + passed + '/' + all.length + ' tests passed ===');
if (passed === all.length) {
  console.log('ALL TESTS PASSED — the verifySvixSignature algorithm is CORRECT.');
} else {
  console.log('SOME TESTS FAILED — review output above.');
  process.exitCode = 1;
}
