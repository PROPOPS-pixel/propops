const fs = require('fs');
const content = fs.readFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/views/dashboard.html', 'utf8');
const tradeContent = fs.readFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/public/propops-trade.html', 'utf8');

console.log('=== propops-trade.html check ===');
const checks = [
  ['.sticky-cta CSS class', '.sticky-cta', false],
  ['class="sticky-cta" element', 'class="sticky-cta"', false],
  ['sticky-cta media query', '.sticky-cta { display: block', false]
];
checks.forEach(([label, search, shouldExist]) => {
  const found = tradeContent.includes(search);
  const ok = shouldExist === found;
  console.log((ok ? '✓' : '✗') + ' ' + label + ': ' + (found ? 'FOUND' : 'NOT FOUND'));
});

console.log();
console.log('=== dashboard.html structure check ===');
const sectionChecks = [
  ['Email Intake section', 'Email Intake — Auto-Forward Leads'],
  ['Pipeline bar', 'Pipeline overview bar'],
  ['Kanban board', 'Kanban board'],
  ['Setup Guide standalone (should be removed)', 'id="tradeSetupGuideSection"'],
  ['Help footer (should be removed)', '<!-- ─── Help footer'],
  ['My Services body', 'id="tradeServicesBody"'],
  ['Pipeline bar div', 'id="tradePipelineBar"'],
  ['Pipeline labels div', 'id="tradePipelineLabels"'],
  ['Setup Guide button in action bar', 'id="tradeSetupGuideBtn"']
];
sectionChecks.forEach(([label, search]) => {
  const found = content.indexOf(search);
  console.log((found === -1 ? '✗' : '✓') + ' ' + label + ': ' + (found === -1 ? 'NOT FOUND' : 'pos ' + found));
});

// Check order: Email Intake should come before Pipeline bar, which should come before Kanban
const emailIntakePos = content.indexOf('Email Intake — Auto-Forward Leads');
const pipelinePos = content.indexOf('Pipeline overview bar');
const kanbanPos = content.indexOf('<!-- Kanban board -->');
console.log();
console.log('Order: Email Intake (pos ' + emailIntakePos + ') < Pipeline (pos ' + pipelinePos + ') < Kanban (pos ' + kanbanPos + ')');
if (emailIntakePos !== -1 && pipelinePos !== -1 && kanbanPos !== -1) {
  if (emailIntakePos < pipelinePos && pipelinePos < kanbanPos) {
    console.log('✓ CORRECT ORDER: Email Intake → Pipeline bar → Kanban board');
  } else {
    console.log('✗ WRONG ORDER!');
  }
}