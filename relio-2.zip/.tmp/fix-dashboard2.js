const fs = require('fs');
const content = fs.readFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/views/dashboard.html', 'utf8');

// Find Setup Guide section boundaries
const setupGuideStart = content.indexOf('<!-- ─── Setup Guide Section (Trade mode) ─ own collapsible at bottom ─ -->');
const helpFooterStart = content.indexOf('<!-- ─── Help footer (Trade mode) ──────────────────────────────────── -->');
const tradeModeClose = content.indexOf('      </div><!-- /tradeMode -->');

console.log('Setup Guide start:', setupGuideStart, '-', content.substring(setupGuideStart, setupGuideStart+80));
console.log('Help footer start:', helpFooterStart, '-', content.substring(helpFooterStart, helpFooterStart+80));
console.log('tradeMode close:', tradeModeClose, '-', content.substring(tradeModeClose-50, tradeModeClose+50));

// Show the content between Setup Guide and Help footer
const between = content.substring(setupGuideStart, helpFooterStart);
console.log('\n=== Content between Setup Guide and Help footer ===');
console.log('Length:', between.length, 'chars');
console.log('First 200 chars:', JSON.stringify(between.substring(0, 200)));
console.log('Last 200 chars:', JSON.stringify(between.substring(between.length-200)));

// Show content from Help footer to tradeMode close
const afterFooter = content.substring(helpFooterStart, tradeModeClose);
console.log('\n=== Content from Help footer to tradeMode close ===');
console.log('Length:', afterFooter.length, 'chars');
console.log('First 200 chars:', JSON.stringify(afterFooter.substring(0, 200)));
console.log('Last 200 chars:', JSON.stringify(afterFooter.substring(afterFooter.length-200)));