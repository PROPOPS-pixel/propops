const reply = 'That\'s $363 including GST for a plumber visit. Want me to lock that in?\n[QUOTE:{"trade":"plumber","urgency":"normal","hours":1.5,"materials":0,"customer_name":"John","job_type":"leaking tap"}]';
const markerRe = /\[QUOTE:(\{[^}]+\})\]/s;
const match = markerRe.exec(reply);
console.log('Found marker:', match !== null);
if (match) {
  const parsed = JSON.parse(match[1]);
  console.log('Parsed data:', JSON.stringify(parsed));
  console.log('Clean reply:', reply.replace(markerRe, '').trim());
}
