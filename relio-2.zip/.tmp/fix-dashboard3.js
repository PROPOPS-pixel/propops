const fs = require('fs');
let content = fs.readFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/views/dashboard.html', 'utf8');

// ---- EDIT 2: Remove Setup Guide standalone section + Help footer ----
// Both sections come right before </div><!-- /tradeMode -->
const setupGuideStart = content.indexOf('<!-- ─── Setup Guide Section (Trade mode) ─ own collapsible at bottom ─ -->');
const helpFooterStart = content.indexOf('<!-- ─── Help footer (Trade mode) ──────────────────────────────────── -->');
const tradeModeClose = content.indexOf('      </div><!-- /tradeMode -->');

// Remove from Setup Guide start to just before tradeModeClose (but preserve one blank line)
const oldSections = content.substring(setupGuideStart, tradeModeClose);
console.log('Removing sections (' + oldSections.length + ' chars):');
console.log('START:', JSON.stringify(oldSections.substring(0, 80)));
console.log('END:', JSON.stringify(oldSections.substring(oldSections.length - 80)));

const newSections = '\n      </div><!-- /tradeMode -->';
const newContent = content.substring(0, setupGuideStart) + newSections + content.substring(tradeModeClose);

if (newContent.includes(oldSections)) {
  console.log('✗ OLD STRING STILL FOUND - replacement failed');
} else {
  console.log('✓ Sections removed from dashboard.html');
}

fs.writeFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/views/dashboard.html', newContent);

// ---- EDIT 3: Add Setup Guide button to action bar ----
content = fs.readFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/views/dashboard.html', 'utf8');

// Find the action bar (trade-simulate-bar) and add Setup Guide button
// The action bar ends with cfTradeBarBtn button
const cfBtnMarker = 'id="cfTradeBarBtn" onclick="openCallForwardModal()"';
const cfBtnIdx = content.indexOf(cfBtnMarker);
if (cfBtnIdx === -1) {
  console.log('✗ cfTradeBarBtn not found');
} else {
  // Find the end of this button tag (it has inline styles, find </button>)
  const btnEnd = content.indexOf('</button>', cfBtnIdx);
  const oldString = content.substring(cfBtnIdx, btnEnd + 9); // include </button>
  const newString = oldString + '\n            <button id="tradeSetupGuideBtn" onclick="toggleTradeSetupGuide()" style="padding:5px 12px;background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.3);border-radius:6px;color:#f59e0b;font-size:0.78rem;font-weight:600;cursor:pointer;">📋 Setup Guide</button>';

  if (content.includes(oldString)) {
    content = content.replace(oldString, newString);
    fs.writeFileSync('/opt/polsia/workspaces/company-55743/agent-30/exec-2098447/relio-2/views/dashboard.html', content);
    console.log('✓ Setup Guide button added to action bar');
  } else {
    console.log('✗ Action bar button string not found');
    console.log('Looking for:', JSON.stringify(oldString.substring(0, 100)));
  }
}

console.log('\n=== VERIFICATION ===');
// Check new structure
const newIdx = content.indexOf('<!-- ─── Email Intake');
const pipelineIdx = content.indexOf('<!-- Pipeline overview bar');
const kanbanIdx = content.indexOf('<!-- Kanban board -->');
const setupGuideIdx = content.indexOf('id="tradeSetupGuideSection"');
const helpFooterIdx = content.indexOf('id="tradeIntakeSection"'); // should still be there
const helpFooterIdx2 = content.indexOf('<!-- ─── Help footer');

console.log('Email Intake position:', newIdx);
console.log('Pipeline bar position:', pipelineIdx);
console.log('Kanban board position:', kanbanIdx);
console.log('Setup Guide section (should be -1 after removal):', setupGuideIdx);
console.log('Help footer (should be -1 after removal):', helpFooterIdx2);

if (newIdx !== -1 && pipelineIdx !== -1 && kanbanIdx !== -1) {
  console.log('\nOrder check:');
  if (newIdx < pipelineIdx && pipelineIdx < kanbanIdx) {
    console.log('✓ CORRECT ORDER: Email Intake → Pipeline bar → Kanban');
  } else {
    console.log('✗ WRONG ORDER!');
    console.log('Email Intake:', newIdx, 'Pipeline:', pipelineIdx, 'Kanban:', kanbanIdx);
  }
}